I need some holes not plated.
Please check "RaSK_General-Rocket-Logger-NPTH.TXT".